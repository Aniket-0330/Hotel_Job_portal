# online_jobsearch_portal
Developed an online job search platform using technologies such as Java, MySQL, JDBC, JSP, HTML, CSS, Bootstrap, and JavaScript. Implemented features including job posting, job searching, candidate profile editing, and candidate selection.
